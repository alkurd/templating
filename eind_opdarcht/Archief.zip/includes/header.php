<!doctype html>
<html lang="en">
<head>
  <meta charset="utf-8">
  <title>Lab 2 - Includes en require</title>
  <link rel="stylesheet" href="/templating/eind_opdarcht/css/style.css">
</head>
<body>
    <div>
        <header class='site-header'>
            <nav class='nav-bar'>
                <a href="?page=home">Home</a>
                <a href="?page=onderwerp1">Onderwerp 1</a>
                <a href="?page=onderwerp2">Onderwerp 2</a>
                <a href="?page=onderwerp3">Onderwerp 3</a>
            </nav>
        </header>

        
