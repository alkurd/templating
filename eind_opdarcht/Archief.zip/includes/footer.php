        <footer class='site-footer'> &copy YAlkurdi <?= date("Y")?> </footer>
    </div>
</body>
</html>