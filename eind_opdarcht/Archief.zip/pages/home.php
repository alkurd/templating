<h1>welkom</h1>
<?php
$gekozenIndex= 0;
include 'images/fotos.php';