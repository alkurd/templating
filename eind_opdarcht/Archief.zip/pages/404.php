<h1 class="error-message">
    404
</h1>
<h2 class="error-message">
    Page not found
</h2>